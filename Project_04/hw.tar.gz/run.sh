#!/bin/sh

python3 ./trietime.py $@