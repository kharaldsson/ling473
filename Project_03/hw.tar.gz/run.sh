#!/bin/sh

python3 ./fsa.py $@